<div class="sidebar">
    <h3 id="kategoriler">Kategoriler</h3>
    <ul class="main-ul">
        <li class="top-category">

            <ul class="sub-category">
                <?php
                // echo '<li><a href="urunler.php">Tüm Ürünler</a></li>';
                echo '<li><a href="admin_paneli.php">Admin Paneli</a></li>';
                echo '<li><a href="firma_paneli.php">Firma Paneli</a></li>';

                echo '<br><p>(Hızlı sayfa erişimi adına bilerek bırakılmıştır)</p>';
                // foreach ($category as $key => $value) { // Kategorileri listele
                //     echo '<li><a href="urunler.php?kategori=' . $value['id'] . '">' . $value['kategori_adi'] . '</a></li>';
                // }

                ?>
            </ul>
        </li>
    </ul>
</div>