<div class="sidebar">
    <h3 id="kategoriler">Yönetim</h3>
    <ul class="main-ul">
        <li class="top-category">

            <ul class="sub-category">
                <?php
                // echo '<li><a href="firma_paneli.php">Sipariş Kayıtları</a></li>';
                // echo '<li><a href="urun_yonetimi.php">Ürün Yönetimi</a></li>';
                echo '<li><a href="admin_paneli.php">Admin Paneli</a></li>';
                echo '<li><a href="firma_paneli.php">Firma Paneli</a></li>';
                ?>
            </ul>
        </li>
    </ul>
</div>